from questions import questions

question_prompts = [

  "Is Marvel Studios’ Avengers: Endgame the highest grossing superhero film ever?\n(a) True\n(b) False\n\n",
   "Which movie did Spider-Man appear in the Avengers franchise?\n(a) Iron Man\n(b) Avengers:Age of Ultron\n(c) Captain America:Civil War\n\n",
    "How best can you describe Captain America?\n(a) Rude\n(b) violent\n(c) weak\n(d) courageous\n(e)",
    "What Marvel movie was made without a script? Avengers: Infinity War\n(a) Spider-Man Far from Home\n(b) Doctor Strange\n(c) Iron Man\n(d)",
    "Is Thor weapon a shield?\n(a) True\n(b) False\n\n",
]

questions = [
   questions(question_prompts[0], "a"),
    questions(question_prompts[1], "c"),
    questions(question_prompts[2], "e"),
    questions(question_prompts[3],"a"),
    questions(question_prompts[4], "b"),
]

def run_test(questions):
    score = 0
    for question in questions:
        answer = input(question.prompt)
        if answer == question.answer:
               score += 1
       print("you got " + str(score) + "/" + str(len(questions)) +"correct")

run_test(questions)